# Дело 04. Ночной сигнал архива

Четвертый проект: индексатор папки после ночного сигнала архива. Он собирает JSON-манифест, ищет дубли по SHA-256 и показывает изменения между запусками.

## Подготовка

Нужна современная версия Python 3.

### Windows PowerShell

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

### macOS или Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## Запуск

```bash
python secret_folder_archive.py
```

Стартовый файл пустой. В главе вы вручную добавите обход `data/secret_folder/`, SHA-256, timestamps, JSON-манифест, поиск дублей и сравнение с прошлым запуском.

Хэш SHA-256 работает как цифровой отпечаток файла: одинаковые байты дают одинаковую строку, а маленькая правка меняет ее.

## Что изучаем

- `pathlib.Path`;
- рекурсивный обход файлов;
- `hashlib.sha256`;
- JSON;
- timestamps в UTC;
- поиск дублей;
- обнаружение добавленных, удаленных и измененных файлов;
- `rich.console.Console` и `rich.table.Table`.
