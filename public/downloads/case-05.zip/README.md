# Дело 05. Доска расследования

Пятый проект: небольшая ООП-доска для расследования ночного сигнала архива. Мы храним участников, улики и заметки как объекты, загружаем исходные данные из JSON и сохраняем обновленный снимок дела.

## Подготовка

Нужна современная версия Python 3.

### Windows PowerShell

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

### macOS или Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## Запуск

```bash
python investigation_system.py
```

Стартовый файл пустой. В главе вы вручную добавите загрузку `data/case_seed.json`, поиск по уликам, методы объектов, заметки и сохранение JSON-снимка `case_report.json`.

## Что изучаем

- классы и методы;
- `dataclass` для компактных объектов;
- композицию: дело содержит участников, улики и заметки;
- чтение и запись JSON;
- `pathlib.Path`;
- `rich.console.Console` и `rich.table.Table` для терминального отчета.
